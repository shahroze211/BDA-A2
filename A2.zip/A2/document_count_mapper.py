#!/usr/bin/env python

import sys

# Pass through (word, count) pairs from previous step
for line in sys.stdin:
    print(line.strip())

