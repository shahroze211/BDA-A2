#!/usr/bin/env python

import sys
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer

# Download NLTK data if not already downloaded
nltk.download('punkt')
nltk.download('stopwords')

stop_words = set(stopwords.words('english'))
stemmer = PorterStemmer()

# Tokenize and preprocess the query
def preprocess(text):
    tokens = word_tokenize(text.lower())
    tokens = [stemmer.stem(token) for token in tokens if token.isalnum() and token not in stop_words]
    return tokens

# Read the user-provided query
query = sys.stdin.read().strip()

# Tokenize and preprocess the query terms and emit (term, 1) pairs
for term in preprocess(query):
    print(f"{term}\t1")

