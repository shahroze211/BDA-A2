#!/usr/bin/env python

import sys
import math

total_documents = 0

# Accumulate document counts for each term
for line in sys.stdin:
    total_documents += 1

# Calculate IDF for each term
idf_values = {}
for line in sys.stdin:
    word, count = line.strip().split('\t')
    count = int(count)
    idf_values[word] = math.log(total_documents / (count + 1))

# Output IDF values
for word, idf in idf_values.items():
    print(f"{word}\t{idf}")

