#!/usr/bin/env python

import sys
import math

idf_values = {}

# Load IDF values into memory
for line in open('idf_values.txt', 'r'):
    word, idf = line.strip().split('\t')
    idf_values[word] = float(idf)

# Read the (term, 1) pairs from the mapper and calculate TF-IDF weights for the query
query_tfidf = {}
total_terms = 0

for line in sys.stdin:
    term, _ = line.strip().split('\t')
    query_tfidf[term] = query_tfidf.get(term, 0) + 1
    total_terms += 1

for term, count in query_tfidf.items():
    tf = count / total_terms
    query_tfidf[term] = tf * idf_values.get(term, 0.0)

# Output TF-IDF weights for the query
print(query_tfidf)

