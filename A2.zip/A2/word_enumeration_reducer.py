#!/usr/bin/env python

import sys

current_word = None
word_count = 0

# Aggregate word counts
for line in sys.stdin:
    word, count = line.strip().split('\t', 1)
    count = int(count)
    
    if current_word == word:
        word_count += count
    else:
        if current_word:
            print(f"{current_word}\t{word_count}")
        current_word = word
        word_count = count

# Output the last word
if current_word:
    print(f"{current_word}\t{word_count}")

