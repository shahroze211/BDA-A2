#!/usr/bin/env python

import sys
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

# Load TF-IDF weights for the query into memory
query_tfidf = {}
for line in open('query_tfidf.txt', 'r'):
    term, weight = line.strip().split('\t')
    query_tfidf[term] = float(weight)

# Calculate cosine similarity between the query vector and document vectors
document_vectors = []
for line in sys.stdin:
    doc_id, tfidf_str = line.strip().split('\t', 1)
    tfidf_dict = eval(tfidf_str)
    document_vector = [tfidf_dict.get(term, 0.0) for term in query_tfidf.keys()]
    document_vectors.append(document_vector)

document_vectors = np.array(document_vectors)
query_vector = np.array(list(query_tfidf.values())).reshape(1, -1)

similarity_scores = cosine_similarity(query_vector, document_vectors)
ranked_indices = np.argsort(similarity_scores, axis=1)[0][::-1]

# Emit ranked documents
for idx in ranked_indices:
    print(f"Rank {idx + 1}: Document {idx + 1}")

