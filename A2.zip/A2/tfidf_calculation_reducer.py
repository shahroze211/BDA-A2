#!/usr/bin/env python

import sys

idf_values = {}

# Load IDF values into memory
for line in open('idf_values.txt', 'r'):
    word, idf = line.strip().split('\t')
    idf_values[word] = float(idf)

# Calculate TF-IDF for each term in each document
current_doc_id = None
tf_document = {}

for line in sys.stdin:
    doc_id, word_count = line.strip().split('\t')
    doc_id = int(doc_id)
    word, count = word_count.split()
    count = int(count)
    
    if current_doc_id == doc_id:
        tf_document[word] = count / sum(tf_document.values())
    else:
        if current_doc_id is not None:
            tfidf_document = {word: tf * idf_values[word] for word, tf in tf_document.items()}
            print(f"{current_doc_id}\t{tfidf_document}")
        current_doc_id = doc_id
        tf_document = {word: count}

# Output TF-IDF for the last document
if current_doc_id is not None:
    tfidf_document = {word: tf * idf_values[word] for word, tf in tf_document.items()}
    print(f"{current_doc_id}\t{tfidf_document}")

