#!/usr/bin/env python

import sys

# Pass through (document_id, TF-IDF_vector) pairs
for line in sys.stdin:
    print(line.strip())

