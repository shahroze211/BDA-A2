#!/usr/bin/env python

import sys
import math

# Pass through (word, count) pairs from Step 1
for line in sys.stdin:
    print(line.strip())

