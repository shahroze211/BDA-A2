#!/usr/bin/env python

import sys
import nltk
from nltk.tokenize import word_tokenize

# Download NLTK data if not already downloaded
nltk.download('punkt')

# Tokenize text into words and emit (word, 1) pairs
for line in sys.stdin:
    parts = line.strip().split(',')
    if len(parts) >= 4:
        text = parts[3]
        for word in word_tokenize(text):
            if word.isalnum():
                print(f"{word.lower()}\t1")

